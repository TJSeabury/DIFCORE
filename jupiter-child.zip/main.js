/*
* Main scripts
* @author DIF Design http://difdesign.com/
* @version 0.9.0
*/
'use strict';

(function main(D,$) {
	
	// code . . .
	
})(DIFDesignCoreUtilities,jQuery);






